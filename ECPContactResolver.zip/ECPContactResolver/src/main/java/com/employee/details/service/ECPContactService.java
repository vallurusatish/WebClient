package com.employee.details.service;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employee.details.dto.ECPRequestDTO;
import com.employee.details.dto.ECPResponseDTO;
import com.employee.details.exceptions.ECPResolverPartyIdNotFoundException;
import com.employee.details.model.PartyUUID;
import com.employee.details.repository.ECPContactRepository;

@Service
public class ECPContactService {
	
	@Autowired(required = true)
	private ECPContactRepository ecpContactRepository;
	
	@Autowired
	private ModelMapper mapper;

	public ECPResponseDTO findByPartyUuid(ECPRequestDTO ecpRequestDTO) {
		
		PartyUUID ecpPartyUuid = ecpContactRepository.findBypartyUuid(ecpRequestDTO.getPartyUuid());
		if(ecpPartyUuid==null || ecpPartyUuid.getPartyUuid()==null || ecpRequestDTO.getPartyUuid()==null) {
			throw new ECPResolverPartyIdNotFoundException(ecpRequestDTO.getTrackingNumber());
		}
		ECPResponseDTO response = new ECPResponseDTO();
		response.setTrackingNumber(ecpRequestDTO.getTrackingNumber());
		BeanUtils.copyProperties(ecpPartyUuid, response);
		return response;
	}
	
	public List<PartyUUID> findByAllPartyUuid() {
		List<PartyUUID> response = ecpContactRepository.findAll();
		System.out.println("response" + response);
		return response;
	}
	
}
