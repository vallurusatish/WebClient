package com.employee.details.dto;

public class ECPRequestDTO {

	private String partyUuid;

	private String trackingNumber;

	public String getPartyUuid() {
		return partyUuid;
	}

	public void setPartyUuid(String partyUuid) {
		this.partyUuid = partyUuid;
	}

	public String getTrackingNumber() {
		return trackingNumber;
	}

	public void setTrackingNumber(String trackingNumber) {
		this.trackingNumber = trackingNumber;
	}

}
