package com.employee.details.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.employee.details.dto.ECPRequestDTO;
import com.employee.details.model.PartyUUID;

@Repository
public interface ECPContactRepository extends JpaRepository<PartyUUID, String>{

	PartyUUID findBypartyUuid(String partyId);

}
