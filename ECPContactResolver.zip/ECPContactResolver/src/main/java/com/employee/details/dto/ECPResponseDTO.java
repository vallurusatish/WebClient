package com.employee.details.dto;

public class ECPResponseDTO {

	private String trackingNumber;

	private String partyUuid;

	private String contactId;

	public String getTrackingNumber() {
		return trackingNumber;
	}

	public void setTrackingNumber(String trackingNumber) {
		this.trackingNumber = trackingNumber;
	}

	public void setPartyUuid(String partyUuid) {
		this.partyUuid = partyUuid;
	}

	public void setContactId(String contactId) {
		this.contactId = contactId;
	}

	public String getPartyUuid() {
		return partyUuid;
	}

	public String getContactId() {
		return contactId;
	}

}
