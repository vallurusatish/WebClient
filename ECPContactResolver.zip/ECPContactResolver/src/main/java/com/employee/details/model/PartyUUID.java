package com.employee.details.model;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Data
@ToString

@Entity
@Table(name="party_table")
public class PartyUUID {
	
	@Id
	@Column
	private String partyUuid;
	
	@Column
	private String contactId;

	public String getPartyUuid() {
		return partyUuid;
	}

	public void setPartyUuid(String partyUuid) {
		this.partyUuid = partyUuid;
	}

	public String getContactId() {
		return contactId;
	}

	public void setContactId(String contactId) {
		this.contactId = contactId;
	}

}
