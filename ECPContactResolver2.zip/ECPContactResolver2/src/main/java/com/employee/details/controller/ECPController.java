package com.employee.details.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.employee.details.dto.ECPRequestDTO;
import com.employee.details.dto.ECPResponseDTO;
import com.employee.details.model.PartyUUID;
import com.employee.details.service.ECPContactService;

@RestController
public class ECPController {
	
	@Autowired
	private ECPContactService ecpContactService;
	
	/*
	 * @PostMapping public
	 */
	@PostMapping("/ecpConfig")
	
	public ResponseEntity<ECPResponseDTO> getPartyUuid(@RequestBody ECPRequestDTO ecpRequestDTO){
		
		ECPResponseDTO listPartyUuid = ecpContactService.findByPartyUuid(ecpRequestDTO);
		return ResponseEntity.status(HttpStatus.OK).body(listPartyUuid);
		
	}
	
	@GetMapping("/ecpdata/all")
	public ResponseEntity<List<PartyUUID>> getAllPartyUuid(){
		List<PartyUUID> lists = new ArrayList<PartyUUID>();
		lists = ecpContactService.findByAllPartyUuid();
		System.out.println(lists);

		return ResponseEntity.status(HttpStatus.OK).body(lists);
		
	}

}
