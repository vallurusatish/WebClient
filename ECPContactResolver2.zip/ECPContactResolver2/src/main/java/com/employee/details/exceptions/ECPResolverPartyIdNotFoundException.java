package com.employee.details.exceptions;

public class ECPResolverPartyIdNotFoundException extends RuntimeException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String trackingNumber;

	public ECPResolverPartyIdNotFoundException(String trackingNumber) {
		this.trackingNumber=trackingNumber;
	}

	public String getTrackingNumber() {
		return trackingNumber;
	}

	public void setTrackingNumber(String trackingNumber) {
		this.trackingNumber = trackingNumber;
	}

}
