package com.employee.details.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.employee.details.dto.ResponseMsg;

@RestControllerAdvice
public class WebRestControllerAdvice extends ResponseEntityExceptionHandler{
	
	@ExceptionHandler(value=ECPResolverPartyIdNotFoundException.class)
	public ResponseEntity<ResponseMsg> handleNotFoundException(ECPResolverPartyIdNotFoundException ex){
		ResponseMsg responseMsg = new ResponseMsg();
		responseMsg.setStatus("ERROR");
		responseMsg.setErrorType("PARTYID is required.");
		responseMsg.setResponseCode("101");
		responseMsg.setTrackingNumber(ex.getTrackingNumber());
		responseMsg.setMessage("No correspondence between partyId and contactid");
		return new ResponseEntity<>(responseMsg, HttpStatus.OK);
		
	}

}
