package com.employee.details.dto;

public class ECPResponseDTO {

	private String trackingNumber;

	private String campaignId;

	private String journeyId;
	
	private String underWritingCompany;

	public String getTrackingNumber() {
		return trackingNumber;
	}

	public void setTrackingNumber(String trackingNumber) {
		this.trackingNumber = trackingNumber;
	}

	public String getCampaignId() {
		return campaignId;
	}

	public void setCampaignId(String campaignId) {
		this.campaignId = campaignId;
	}

	public String getJourneyId() {
		return journeyId;
	}

	public void setJourneyId(String journeyId) {
		this.journeyId = journeyId;
	}

	public String getUnderWritingCompany() {
		return underWritingCompany;
	}

	public void setUnderWritingCompany(String underWritingCompany) {
		this.underWritingCompany = underWritingCompany;
	}

	

}
