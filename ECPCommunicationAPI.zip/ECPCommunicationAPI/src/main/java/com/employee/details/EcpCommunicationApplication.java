package com.employee.details;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcpCommunicationApplication {

	public static void main(String[] args) {
		SpringApplication.run(EcpCommunicationApplication.class, args);
	}

}
