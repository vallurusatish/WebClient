package com.employee.details.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.employee.details.model.PartyUUID;

@RestControllerAdvice
public class WebRestControllerAdvice extends ResponseEntityExceptionHandler{
	
	@ExceptionHandler(value=ECPResolverPartyIdNotFoundException.class)
	public ResponseEntity<PartyUUID> handleNotFoundException(ECPResolverPartyIdNotFoundException ex){
		PartyUUID responseMsg = new PartyUUID();
		return new ResponseEntity<>(responseMsg, HttpStatus.BAD_REQUEST);
		
	}

}
