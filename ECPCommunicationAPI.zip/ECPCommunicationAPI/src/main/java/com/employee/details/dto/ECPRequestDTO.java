package com.employee.details.dto;

public class ECPRequestDTO {

	private String partyUuid;
	
	private String campaignId;

	public String getCampaignId() {
		return campaignId;
	}

	public void setCampaignId(String campaignId) {
		this.campaignId = campaignId;
	}

	private String trackingNumber;

	public String getPartyUuid() {
		return partyUuid;
	}

	public void setPartyUuid(String partyUuid) {
		this.partyUuid = partyUuid;
	}

	public String getTrackingNumber() {
		return trackingNumber;
	}

	public void setTrackingNumber(String trackingNumber) {
		this.trackingNumber = trackingNumber;
	}

}
