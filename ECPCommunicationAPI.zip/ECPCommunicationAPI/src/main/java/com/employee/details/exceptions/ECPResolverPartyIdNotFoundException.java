package com.employee.details.exceptions;

public class ECPResolverPartyIdNotFoundException extends RuntimeException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ECPResolverPartyIdNotFoundException(String mes) {
		super(mes);
	}

}
