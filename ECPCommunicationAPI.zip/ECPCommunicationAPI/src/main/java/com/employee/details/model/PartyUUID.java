package com.employee.details.model;

public class PartyUUID {
	private String partyUuid;

	private Long contactId;
	

	public String getPartyUuid() {
		return partyUuid;
	}
	public void setPartyUuid(String partyUuid) {
		this.partyUuid = partyUuid;
	}
	public Long getContactId() {
		return contactId;
	}
	public void setContactId(Long contactId) {
		this.contactId = contactId;
	}
	
	
	

}
