package com.employee.details.model;

public class ECPData {
	
	private PartyUUID partyUUID;

	public PartyUUID getPartyUUID() {
		return partyUUID;
	}

	public void setPartyUUID(PartyUUID partyUUID) {
		this.partyUUID = partyUUID;
	}

}
