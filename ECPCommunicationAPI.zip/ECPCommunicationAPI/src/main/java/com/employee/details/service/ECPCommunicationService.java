package com.employee.details.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.employee.details.dto.ECPCampaignIdResponseDTO;
import com.employee.details.dto.ECPFinalResponseDTO;
import com.employee.details.dto.ECPPartyIdResponseDTO;
import com.employee.details.dto.ECPRequestDTO;

import reactor.core.publisher.Mono;

@Service
public class ECPCommunicationService {
	/*
	 * @Autowired private ModelMapper mapper;
	 */

	@Value("${ecpcontactservice.base.url}")
	private String ecpcontactserviceurl;
	
	@Value("${ecpconfigurationservice.base.url}")
	private String ecpconfigurationserviceurl;
	
	@Autowired(required = true)
	private WebClient webClient;
	
	
	private Logger LOGGER = LoggerFactory.getLogger(ECPCommunicationService.class);

	public ECPFinalResponseDTO finalResponse(ECPRequestDTO ecpRequestDTO){
		
		ECPFinalResponseDTO ecpFinalResponseDTO = new ECPFinalResponseDTO();
		
		ECPPartyIdResponseDTO ecpResponseDTO = getByPartyUuid(ecpRequestDTO);
		System.out.println("re :" + ecpResponseDTO);
		ECPCampaignIdResponseDTO ecpCampaignIdResponseDTO = getByCampaignId(ecpRequestDTO); 
		System.out.println("re :" + ecpCampaignIdResponseDTO);
		BeanUtils.copyProperties(ecpResponseDTO, ecpFinalResponseDTO);
		BeanUtils.copyProperties(ecpCampaignIdResponseDTO, ecpFinalResponseDTO);
		return ecpFinalResponseDTO;

	}
	
	public ECPPartyIdResponseDTO getByPartyUuid(ECPRequestDTO ecpRequestDTO) {
		System.out.println("re :" + ecpRequestDTO.getPartyUuid());

		ECPPartyIdResponseDTO ecpResponseDTO = null;		

		// Using WebClient
		ecpResponseDTO = webClient.post().uri(ecpcontactserviceurl)
						.body(Mono.just(ecpRequestDTO), ECPRequestDTO.class).retrieve().bodyToMono(ECPPartyIdResponseDTO.class).block();
						
		
		//partyUUID2 = webClient.get().uri(UriBuilder -> UriBuilder.path("/ecpdata").build()).retrieve().bodyToMono(PartyUUID.class).block();
		/*
		 * if(partyUUID2.equalsIgnoreCase("Error")) { return partyUUID2;
		 * 
		 * }
		 */
		
		System.out.println("re :" + ecpResponseDTO.getPartyUuid());

		return ecpResponseDTO;
	}
	
	public ECPCampaignIdResponseDTO getByCampaignId(ECPRequestDTO ecpRequestDTO) {
		System.out.println("re :" + ecpRequestDTO.getCampaignId());

		ECPCampaignIdResponseDTO ecpResponseDTO = null;
		
		ecpResponseDTO = webClient.post().uri(ecpconfigurationserviceurl)
				.body(Mono.just(ecpRequestDTO), ECPRequestDTO.class).retrieve().bodyToMono(ECPCampaignIdResponseDTO.class).block();
				
		System.out.println("re :" + ecpResponseDTO.getCampaignId());

		return ecpResponseDTO;
	}

}
