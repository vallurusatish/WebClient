package com.employee.details.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.employee.details.dto.ECPFinalResponseDTO;
import com.employee.details.dto.ECPRequestDTO;
import com.employee.details.service.ECPCommunicationService;

@RestController
public class ECPController {
	
	@Autowired
	private ECPCommunicationService ecpCommunicationService;
	
	/*
	 * @PostMapping public
	 */
	@PostMapping("/ecp")
	public ResponseEntity<ECPFinalResponseDTO> getPartyUuid(@RequestBody ECPRequestDTO ecpRequestDTO){
		
		ECPFinalResponseDTO listPartyUuid = ecpCommunicationService.finalResponse(ecpRequestDTO);
		return ResponseEntity.status(HttpStatus.OK).body(listPartyUuid);
				
	}
	
}
